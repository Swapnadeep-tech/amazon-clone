import React from 'react';
import { createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase";

const Signup = () => {
  const handleSignup = async (e) => {
    e.preventDefault();
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, "newuser@example.com", "password123");
      console.log(userCredential.user);
    } catch (error) {
      console.error(error.message);
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">Signup</h2>
      <form onSubmit={handleSignup}>
        <input type="email" placeholder="Email" required className="border p-2 mb-2" />
        <input type="password" placeholder="Password" required className="border p-2 mb-2" />
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">Signup</button>
      </form>
    </div>
  );
};

export default Signup;