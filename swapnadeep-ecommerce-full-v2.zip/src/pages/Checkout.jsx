import React, { useContext } from 'react';
import { CartContext } from '../contexts/CartContext';

const Checkout = () => {
  const { cartItems, handleCheckout } = useContext(CartContext);

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">Checkout</h2>
      <div>
        {cartItems.length === 0 ? (
          <p>No items in cart.</p>
        ) : (
          <ul>
            {cartItems.map(item => (
              <li key={item.id}>
                {item.name} - ₹{item.price}
              </li>
            ))}
          </ul>
        )}
      </div>
      <button onClick={handleCheckout} className="bg-blue-500 text-white px-4 py-2 rounded mt-4">Proceed to Checkout</button>
    </div>
  );
};

export default Checkout;