import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { CartContext } from '../contexts/CartContext';

const products = [
  { id: '1', name: 'Nike Air Zoom', price: 5499 },
  { id: '2', name: 'iPhone 14 Pro', price: 129900 },
  { id: '3', name: 'Atomic Habits', price: 499 }
];

const Home = () => {
  const { addToCart } = useContext(CartContext);

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Welcome to Swapnadeep.com</h1>
      <div className="grid gap-4 grid-cols-1 md:grid-cols-3">
        {products.map(product => (
          <div key={product.id} className="border p-4 rounded shadow">
            <h2 className="font-semibold">{product.name}</h2>
            <p>₹{product.price}</p>
            <div className="flex gap-2 mt-2">
              <Link to={`/product/${product.id}`} className="bg-blue-500 text-white px-2 py-1 rounded">View</Link>
              <button onClick={() => addToCart(product)} className="bg-green-500 text-white px-2 py-1 rounded">Add to Cart</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;