# Full E-commerce Site with All Features

## 🚀 Features
- 🛍️ Product listing, detail pages
- 🛒 Cart system with add/remove functionality
- 🔐 Firebase login/signup (email & Google)
- 💳 Stripe payment integration
- 🖥️ Admin panel (basic)
- 📂 Category filter & product search

## 📦 Setup Instructions
1. `npm install`
2. `npm run dev`
3. Firebase setup in `src/firebase.js`

## 🚀 Deployment
- Push this to GitHub
- Deploy on [Vercel](https://vercel.com)
